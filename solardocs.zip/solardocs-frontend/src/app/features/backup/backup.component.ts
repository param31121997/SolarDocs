import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { BackupService } from '../../core/services/backup.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';
import { TranslateService } from '../../core/i18n/translate.service';

@Component({
  selector: 'app-backup',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatListModule, TranslatePipe],
  templateUrl: './backup.component.html'
})
export class BackupComponent {
  private backupService = inject(BackupService);
  private translate = inject(TranslateService);

  backups = signal<string[]>([]);

  constructor() { this.reload(); }

  reload() { this.backupService.list().subscribe(list => this.backups.set(list)); }

  create() { this.backupService.create().subscribe(() => this.reload()); }

  restore(fileName: string) {
    if (confirm(this.translate.instant('backup.confirmRestore'))) {
      this.backupService.restore(fileName).subscribe(() => this.reload());
    }
  }
}
