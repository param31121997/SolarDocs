import { Component, inject, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../core/services/document.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-generate-document',
  standalone: true,
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule,
    MatInputModule, MatButtonModule, MatTableModule, MatProgressSpinnerModule,
    MatSnackBarModule, MatCardModule, MatIconModule, TranslatePipe
  ],
  templateUrl: './generate-document.component.html',
  styleUrl: './generate-document.component.scss'
})
export class GenerateDocumentComponent {
  customerId = input.required<string>();
  private docService = inject(DocumentService);
  private snackBar = inject(MatSnackBar);
  private fb = inject(FormBuilder);

  templates = signal<any[]>([]);
  selectedTemplate = signal<string>('QUOTATION');
  lineItems = signal<any[]>([{ slNo: 1, item: '', type: '', qty: '', unit: '', rate: 0, gstPercent: '', amount: 0 }]);
  generatedFile = signal<string | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);
  displayedColumns = ['slNo', 'item', 'type', 'qty', 'unit', 'rate', 'gstPercent', 'amount', 'actions'];

  constructor() {
    this.loadTemplates();
  }

  loadTemplates() {
    this.docService.listTemplates().subscribe({
      next: (templates) => {
        this.templates.set(templates);
        if (templates.length > 0) {
          this.selectedTemplate.set(templates[0].code);
        }
      },
      error: (err) => {
        const msg = 'Failed to load templates';
        this.error.set(msg);
        this.snackBar.open(msg, 'Close', { duration: 5000, panelClass: ['error-snackbar'] });
      }
    });
  }

  addLine() {
    this.lineItems.update(items => [...items, {
      slNo: items.length + 1,
      item: '', type: '', qty: '', unit: '', rate: 0, gstPercent: '', amount: 0
    }]);
  }

  removeLine(index: number) {
    this.lineItems.update(items => {
      const updated = items.filter((_, i) => i !== index);
      return updated.map((item, idx) => ({ ...item, slNo: idx + 1 }));
    });
  }

  updateAmount(index: number) {
    this.lineItems.update(items => {
      const item = items[index];
      if (item.rate && item.qty) {
        item.amount = (parseFloat(item.rate) || 0) * (parseFloat(item.qty) || 0);
      }
      return [...items];
    });
  }

  generate() {
    this.error.set(null);
    if (!this.selectedTemplate()) {
      this.snackBar.open('Please select a template', 'Close', { duration: 3000 });
      return;
    }

    if ((this.selectedTemplate() === 'QUOTATION' || this.selectedTemplate() === 'INVOICE') &&
        (!this.lineItems() || this.lineItems().length === 0)) {
      this.snackBar.open('Please add at least one line item', 'Close', { duration: 3000 });
      return;
    }

    this.isLoading.set(true);
    this.docService.generate(this.customerId(), this.selectedTemplate(), { lineItems: this.lineItems() })
      .subscribe({
        next: (doc) => {
          this.isLoading.set(false);
          this.generatedFile.set(doc.filePath);
          this.snackBar.open('Document generated successfully!', 'Close', {
            duration: 5000,
            panelClass: ['success-snackbar']
          });
        },
        error: (err) => {
          this.isLoading.set(false);
          const errMsg = err?.error?.data || err?.error?.message || 'Failed to generate document';
          this.error.set(errMsg);
          this.snackBar.open(errMsg, 'Close', { duration: 5000, panelClass: ['error-snackbar'] });
        }
      });
  }
}
