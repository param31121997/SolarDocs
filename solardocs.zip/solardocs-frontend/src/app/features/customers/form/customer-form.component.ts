import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CustomerService } from '../../../core/services/customer.service';
import { TranslatePipe } from '../../../core/i18n/translate.pipe';
import { Customer } from '../../../core/models/customer.model';

@Component({
  selector: 'app-customer-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatButtonModule, TranslatePipe],
  templateUrl: './customer-form.component.html'
})
export class CustomerFormComponent {
  private fb = inject(FormBuilder);
  private customerService = inject(CustomerService);
  private router = inject(Router);

  form = this.fb.group({
    name: ['', Validators.required],
    mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    addressLine: [''],
    village: [''],
    district: [''],
    state: [''],
    pincode: ['']
  });

  submit() {
  if (this.form.invalid) { this.form.markAllAsTouched(); return; }
  this.customerService.create(this.form.getRawValue() as Partial<Customer>).subscribe(c => {
    this.router.navigate(['/customers', c.customerId]);
  });
}
}
