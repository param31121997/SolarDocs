import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { MatTabsModule } from '@angular/material/tabs';
import { CustomerService } from '../../../core/services/customer.service';
import { Customer } from '../../../core/models/customer.model';
import { TranslatePipe } from '../../../core/i18n/translate.pipe';
import { GenerateDocumentComponent } from '../../documents/generate-document.component';

@Component({
  selector: 'app-customer-detail',
  standalone: true,
  imports: [CommonModule, MatTabsModule, TranslatePipe, GenerateDocumentComponent],
  templateUrl: './customer-detail.component.html'
})
export class CustomerDetailComponent {
  private route = inject(ActivatedRoute);
  private customerService = inject(CustomerService);

  customer = signal<Customer | null>(null);

  constructor() {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.customerService.get(id).subscribe(c => this.customer.set(c));
  }
}
