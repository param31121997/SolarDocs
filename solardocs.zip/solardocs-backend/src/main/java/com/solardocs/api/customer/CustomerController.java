package com.solardocs.api.customer;

import com.solardocs.api.common.ApiResponse;
import com.solardocs.api.customer.dto.*;
import com.solardocs.application.customer.CustomerSearchService;
import com.solardocs.application.customer.CustomerService;
import com.solardocs.application.ports.CustomerIndexRepository;
import com.solardocs.domain.common.Address;
import com.solardocs.domain.customer.Customer;
import com.solardocs.domain.customer.CustomerStatus;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;
    private final CustomerSearchService searchService;

    public CustomerController(CustomerService customerService, CustomerSearchService searchService) {
        this.customerService = customerService;
        this.searchService = searchService;
    }

    @PostMapping
    public ApiResponse<CustomerResponseDto> create(@Valid @RequestBody CreateCustomerRequestDto req) {
        Customer c = customerService.create(req.name(), req.mobile(),
                new Address(req.addressLine(), req.village(), req.district(), req.state(), req.pincode()));
        return ApiResponse.ok(CustomerResponseDto.from(c));
    }

    @GetMapping
    public ApiResponse<List<CustomerIndexRepository.IndexEntry>> list(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String village,
            @RequestParam(required = false) String district) {
        return ApiResponse.ok(searchService.search(q, status, village, district));
    }

    @GetMapping("/{id}")
    public ApiResponse<CustomerResponseDto> get(@PathVariable String id) {
        return ApiResponse.ok(CustomerResponseDto.from(customerService.get(id)));
    }

    @PutMapping("/{id}")
    public ApiResponse<CustomerResponseDto> update(@PathVariable String id, @Valid @RequestBody UpdateCustomerRequestDto req) {
        Customer c = customerService.update(id, req.name(), req.mobile(), req.alternateMobile(),
                new Address(req.addressLine(), req.village(), req.district(), req.state(), req.pincode()),
                req.consumerNumber(), req.applicationNumber(), req.sanctionedLoadKw(), req.plantCapacityKw(),
                req.discom(), req.category());
        return ApiResponse.ok(CustomerResponseDto.from(c));
    }

    @PatchMapping("/{id}/status")
    public ApiResponse<CustomerResponseDto> updateStatus(@PathVariable String id, @Valid @RequestBody UpdateStatusRequestDto req) {
        Customer c = customerService.updateStatus(id, CustomerStatus.valueOf(req.status()));
        return ApiResponse.ok(CustomerResponseDto.from(c));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> archive(@PathVariable String id) {
        customerService.archive(id);
        return ApiResponse.ok(null);
    }
}
