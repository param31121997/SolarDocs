package com.solardocs.api.customer.dto;

import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;

public record UpdateCustomerRequestDto(
        @NotBlank String name,
        @NotBlank String mobile,
        String alternateMobile,
        String addressLine,
        String village,
        String district,
        String state,
        String pincode,
        String consumerNumber,
        String applicationNumber,
        BigDecimal sanctionedLoadKw,
        BigDecimal plantCapacityKw,
        String discom,
        String category
) {}
