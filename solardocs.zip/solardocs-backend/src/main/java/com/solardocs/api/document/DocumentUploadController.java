package com.solardocs.api.document;

import com.solardocs.api.common.ApiResponse;
import com.solardocs.application.document.DocumentUploadService;
import com.solardocs.domain.document.UploadedDocument;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/customers/{customerId}/documents")
public class DocumentUploadController {

    private final DocumentUploadService uploadService;

    public DocumentUploadController(DocumentUploadService uploadService) {
        this.uploadService = uploadService;
    }

    @PostMapping
    public ApiResponse<UploadedDocument> upload(@PathVariable String customerId,
                                                 @RequestParam String docType,
                                                 @RequestParam("file") MultipartFile file) {
        return ApiResponse.ok(uploadService.upload(customerId, docType, file));
    }
}
