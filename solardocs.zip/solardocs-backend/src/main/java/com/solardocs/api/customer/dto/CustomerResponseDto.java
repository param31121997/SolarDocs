package com.solardocs.api.customer.dto;

import com.solardocs.domain.customer.Customer;
import java.math.BigDecimal;
import java.time.Instant;

public record CustomerResponseDto(
        String customerId, String name, String mobile, String alternateMobile,
        String addressLine, String village, String district, String state, String pincode,
        String consumerNumber, String applicationNumber,
        BigDecimal sanctionedLoadKw, BigDecimal plantCapacityKw,
        String discom, String category, String status,
        Instant createdAt, Instant updatedAt
) {
    public static CustomerResponseDto from(Customer c) {
        var a = c.getAddress();
        return new CustomerResponseDto(
                c.getId().value(), c.getName(), c.getMobile(), c.getAlternateMobile(),
                a != null ? a.addressLine() : null, a != null ? a.village() : null,
                a != null ? a.district() : null, a != null ? a.state() : null, a != null ? a.pincode() : null,
                c.getConsumerNumber(), c.getApplicationNumber(),
                c.getSanctionedLoadKw(), c.getPlantCapacityKw(),
                c.getDiscom(), c.getCategory(), c.getStatus().name(),
                c.getCreatedAt(), c.getUpdatedAt()
        );
    }
}
