package com.solardocs.infrastructure.persistence.json;

import com.solardocs.application.ports.CustomerRepository;
import com.solardocs.config.AppDataDirectoryConfig;
import com.solardocs.domain.common.Address;
import com.solardocs.domain.customer.Customer;
import com.solardocs.domain.customer.CustomerId;
import com.solardocs.domain.customer.CustomerStatus;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.stream.Stream;

@Repository
public class JsonCustomerRepository implements CustomerRepository {

    private final AppDataDirectoryConfig dirs;
    private final JsonFileUtils json;
    private final FileLockManager locks;

    public JsonCustomerRepository(AppDataDirectoryConfig dirs, JsonFileUtils json, FileLockManager locks) {
        this.dirs = dirs;
        this.json = json;
        this.locks = locks;
    }

    private Path folderFor(CustomerId id, String name) {
        String sanitized = name == null ? "customer" : name.replaceAll("[\\\\/:*?\"<>|]", "").trim();
        if (sanitized.length() > 40) sanitized = sanitized.substring(0, 40);
        return dirs.customersDir().resolve(id.value() + "-" + sanitized.replace(' ', '-'));
    }

    /** The folder name may drift from the current customer name over time — we locate by CustomerId prefix. */
    private Optional<Path> existingFolder(CustomerId id) {
        if (Files.notExists(dirs.customersDir())) return Optional.empty();
        try (Stream<Path> children = Files.list(dirs.customersDir())) {
            return children.filter(Files::isDirectory)
                    .filter(p -> p.getFileName().toString().startsWith(id.value() + "-"))
                    .findFirst();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(Customer customer) {
        Path folder = existingFolder(customer.getId()).orElseGet(() -> folderFor(customer.getId(), customer.getName()));
        Path customerFile = folder.resolve("customer.json");
        locks.withLock(customerFile, () -> {
            try {
                Files.createDirectories(folder.resolve("Documents"));
                Files.createDirectories(folder.resolve("Images"));
                Files.createDirectories(folder.resolve("GeneratedPDF"));
                Files.createDirectories(folder.resolve("Notes"));

                var record = new CustomerJsonRecord(
                        customer.getId().value(), customer.getName(), customer.getMobile(),
                        customer.getAlternateMobile(),
                        customer.getAddress() != null ? customer.getAddress().addressLine() : null,
                        customer.getAddress() != null ? customer.getAddress().village() : null,
                        customer.getAddress() != null ? customer.getAddress().district() : null,
                        customer.getAddress() != null ? customer.getAddress().state() : null,
                        customer.getAddress() != null ? customer.getAddress().pincode() : null,
                        customer.getConsumerNumber(), customer.getApplicationNumber(),
                        customer.getSanctionedLoadKw(), customer.getPlantCapacityKw(),
                        customer.getDiscom(), customer.getCategory(),
                        customer.getStatus().name(), customer.isArchived(),
                        customer.getUploadedDocuments().stream()
                                .map(d -> new CustomerJsonRecord.UploadedDocRecord(d.id(), d.type(), d.fileName(), d.filePath(), d.uploadedAt()))
                                .toList(),
                        customer.getGeneratedDocuments().stream()
                                .map(d -> new CustomerJsonRecord.GeneratedDocRecord(d.id(), d.templateCode(), d.templateVersion(), d.filePath(), d.generatedAt()))
                                .toList(),
                        customer.getCreatedAt(), customer.getUpdatedAt()
                );
                json.writeAtomic(customerFile, record);
                return null;
            } catch (IOException e) {
                throw new RuntimeException("Failed to save customer " + customer.getId().value(), e);
            }
        });
    }

    @Override
    public Optional<Customer> findById(CustomerId id) {
        Optional<Path> folder = existingFolder(id);
        if (folder.isEmpty()) return Optional.empty();
        try {
            CustomerJsonRecord rec = json.read(folder.get().resolve("customer.json"), CustomerJsonRecord.class);
            if (rec == null) return Optional.empty();
            return Optional.of(toDomain(rec));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean existsById(CustomerId id) {
        return existingFolder(id).isPresent();
    }

    private Customer toDomain(CustomerJsonRecord rec) {
        Customer c = Customer.newCustomer(
                new CustomerId(rec.customerId()), rec.name(), rec.mobile(),
                new Address(rec.addressLine(), rec.village(), rec.district(), rec.state(), rec.pincode())
        );
        c.updateMasterData(rec.name(), rec.mobile(), rec.alternateMobile(),
                new Address(rec.addressLine(), rec.village(), rec.district(), rec.state(), rec.pincode()),
                rec.consumerNumber(), rec.applicationNumber(), rec.sanctionedLoadKw(), rec.plantCapacityKw(),
                rec.discom(), rec.category());
        c.updateStatus(CustomerStatus.valueOf(rec.status()));
        if (rec.archived()) c.archive();
        return c;
    }
}
