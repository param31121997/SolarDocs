package com.solardocs.application.document;

import com.solardocs.application.customer.CustomerService;
import com.solardocs.application.template.TemplateManagementService;
import com.solardocs.config.AppDataDirectoryConfig;
import com.solardocs.domain.customer.Customer;
import com.solardocs.domain.document.GeneratedDocument;
import com.solardocs.domain.template.DocumentTemplate;
import com.solardocs.infrastructure.pdf.DocumentGenerationStrategyFactory;
import com.solardocs.infrastructure.pdf.PdfRenderer;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Service
public class DocumentGenerationService {

    private final CustomerService customerService;
    private final TemplateManagementService templateService;
    private final DocumentGenerationStrategyFactory strategyFactory;
    private final PdfRenderer pdfRenderer;
    private final AppDataDirectoryConfig dirs;

    public DocumentGenerationService(CustomerService customerService, TemplateManagementService templateService,
                                      DocumentGenerationStrategyFactory strategyFactory, PdfRenderer pdfRenderer,
                                      AppDataDirectoryConfig dirs) {
        this.customerService = customerService;
        this.templateService = templateService;
        this.strategyFactory = strategyFactory;
        this.pdfRenderer = pdfRenderer;
        this.dirs = dirs;
    }

    public GeneratedDocument generate(String customerId, String templateCode, Map<String, Object> extraFields) {
        try {
            Customer customer = customerService.get(customerId);
            DocumentTemplate template = templateService.getByCode(templateCode);
            var strategy = strategyFactory.resolve(templateCode);

            Map<String, Object> model = strategy.buildModel(customer, extraFields == null ? Map.of() : extraFields);
            byte[] pdfBytes = pdfRenderer.render(template.htmlFile(), model);

            Path folder = Files.list(dirs.customersDir())
                    .filter(Files::isDirectory)
                    .filter(p -> p.getFileName().toString().startsWith(customerId + "-"))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Customer folder not found for: " + customerId));
            
            Path pdfDir = folder.resolve("GeneratedPDF");
            Files.createDirectories(pdfDir);

            String id = UUID.randomUUID().toString();
            String fileName = templateCode + "_" + template.version() + "_" + System.currentTimeMillis() + ".pdf";
            Path target = pdfDir.resolve(fileName);
            Files.write(target, pdfBytes);

            GeneratedDocument doc = new GeneratedDocument(id, templateCode, template.version(), target.toString(), Instant.now());
            customer.addGeneratedDocument(doc);
            return doc;
        } catch (Exception e) {
            throw new RuntimeException("Failed generating " + templateCode + " for " + customerId + ": " + e.getMessage(), e);
        }
    }
}
