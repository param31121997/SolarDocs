package com.solardocs.application.document;

import com.solardocs.application.customer.CustomerService;
import com.solardocs.config.AppDataDirectoryConfig;
import com.solardocs.domain.document.UploadedDocument;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.UUID;

@Service
public class DocumentUploadService {

    private final CustomerService customerService;
    private final AppDataDirectoryConfig dirs;

    public DocumentUploadService(CustomerService customerService, AppDataDirectoryConfig dirs) {
        this.customerService = customerService;
        this.dirs = dirs;
    }

    public UploadedDocument upload(String customerId, String docType, MultipartFile file) {
        var customer = customerService.get(customerId);
        try {
            Path folder = Files.list(dirs.customersDir())
                    .filter(Files::isDirectory)
                    .filter(p -> p.getFileName().toString().startsWith(customerId + "-"))
                    .findFirst()
                    .orElseThrow();

            boolean isPhoto = docType.startsWith("SITE_PHOTO") || docType.equals("CUSTOMER_SIGNATURE");
            Path targetDir = folder.resolve(isPhoto ? "Images" : "Documents");
            Files.createDirectories(targetDir);

            String id = UUID.randomUUID().toString();
            String safeName = docType + "_" + id.substring(0, 8) + "_" + file.getOriginalFilename();
            Path target = targetDir.resolve(safeName);
            file.transferTo(target);

            UploadedDocument doc = new UploadedDocument(id, docType, file.getOriginalFilename(),
                    target.toString(), Instant.now());
            customer.addUploadedDocument(doc);
            customerService.update(customerId, customer.getName(), customer.getMobile(),
                    customer.getAlternateMobile(), customer.getAddress(), customer.getConsumerNumber(),
                    customer.getApplicationNumber(), customer.getSanctionedLoadKw(), customer.getPlantCapacityKw(),
                    customer.getDiscom(), customer.getCategory());
            return doc;
        } catch (IOException e) {
            throw new RuntimeException("Upload failed for customer " + customerId, e);
        }
    }
}
